from django.db import models
from django.utils import timezone

# Crear modelo para Categoría
class Categoria(models.Model):
    nombre = models.CharField(max_length=100)
    descripcion = models.TextField()
    estado = models.BooleanField(default=True)

    def __str__(self):
        return self.nombre

# Crear modelo para Proveedor
class Proveedor(models.Model):
    nombre = models.CharField(max_length=100)
    contacto = models.CharField(max_length=100)

    def __str__(self):
        return self.nombre

# Crear modelo para Producto
class Producto(models.Model):
    # Unidades posibles para los productos
    UNIDAD_CHOICES = [
        ('kg', 'Kilogramo'),
        ('ml', 'Mililitro'),
        ('litro', 'Litro'),
        ('unidad', 'Unidad'),
    ]

    nombre = models.CharField(max_length=100)
    descripcion = models.TextField()
    categoria = models.ForeignKey(Categoria, on_delete=models.PROTECT)
    precio_unitario = models.DecimalField(max_digits=10, decimal_places=2)
    cantidad = models.PositiveIntegerField()  # Cambiar a PositiveIntegerField
    unidad = models.CharField(max_length=20, choices=UNIDAD_CHOICES)  # Usar choices para la unidad
    sku = models.CharField(max_length=100, unique=True)
    proveedor = models.ForeignKey(Proveedor, on_delete=models.PROTECT)
    estado = models.BooleanField(default=True)
    fecha_creacion = models.DateTimeField(auto_now_add=True)  # Fecha de creación
    fecha_modificacion = models.DateTimeField(auto_now=True)  # Fecha de última modificación

    def __str__(self):
        return f"{self.nombre} ({self.sku})"