from django.shortcuts import render, HttpResponse, redirect, get_object_or_404
from utils.gestor_usuarios import validar_usuario
from django.contrib.auth import authenticate, login
from django.shortcuts import render, redirect
from .models import Producto
from .forms import ProductoForm
from django.contrib import messages

def user_login(request):
    error = None
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        
        if validar_usuario(username, password):
            return redirect('dashboard')  # Redirige al dashboard en lugar de productos_listar
        else:
            error = "Usuario no registrado o credenciales incorrectas."
            
    return render(request, 'account/login.html', {'error': error})

def construction_view(request):
    return user_login(request)  # Reutiliza la misma lógica




# CRUD DE PRODUCTOS
def dashboard(request):
    return render(request, 'account/dashboard.html')


def producto_crear(request):
    if request.method == 'POST':
        form = ProductoForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, '¡Producto creado exitosamente!')
            return redirect('productos_listar')
        else:
            messages.error(request, 'Por favor, completa todos los campos correctamente.')
    else:
        form = ProductoForm()

    return render(request, 'account/productos.html', {'form': form})


def productos_listar(request):
    productos = Producto.objects.all()
    return render(request, 'account/productos_listar.html', {'productos': productos})
    



def producto_editar(request, pk):
    producto = get_object_or_404(Producto, pk=pk)
    if request.method == 'POST':
        form = ProductoForm(request.POST, instance=producto)
        if form.is_valid():
            form.save()
            return redirect('productos_listar')
    else:
        form = ProductoForm(instance=producto)
    return render(request, 'account/producto_form.html', {'form': form, 'editar': True})

def producto_eliminar(request, pk):
    producto = get_object_or_404(Producto, pk=pk)
    if request.method == 'POST':
        producto.delete()
        return redirect('productos_listar')
    return render(request, 'account/producto_confirmar_eliminar.html', {'producto': producto})


def vista_productos(request):
    # Lógica para ver productos o lo que necesites
    productos = Producto.objects.all()
    return render(request, 'account/vista_productos.html', {'productos': productos})